# install.packages("readxl")
library(readxl)
dataset <- read_excel("retail.xlsx")
head(dataset, 5) # 1
